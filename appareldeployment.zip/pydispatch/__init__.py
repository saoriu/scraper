"""Multi-consumer multi-producer dispatching mechanism
"""
__version__ = "2.0.7"
__author__ = "Patrick K. O'Brien"
__license__ = "BSD"
